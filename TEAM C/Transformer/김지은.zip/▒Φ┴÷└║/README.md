## parameter ##
  "model": "transformer",
    "save_model": "model.pt",

    "mode": "train",
    "optim": "Adam",

    "random_seed": 32,
    "clip": 1,

    "batch_size": 256,
    "num_epoch": 200,
    "warm_steps": 4000,

    "hidden_dim": 512,
    "feed_forward_dim": 2048,
    "n_layer": 6,
    "n_head": 8,
    "max_len": 64,
    "dropout": 0.2

## test loss ##

4.602